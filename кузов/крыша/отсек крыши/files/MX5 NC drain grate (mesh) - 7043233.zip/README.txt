MX5 NC drain grate (mesh) by dzc on Thingiverse: https://www.thingiverse.com/thing:7043233

Summary:
created this to for Mazda MX5 NC drains , hope it works for you.Please post a make if it does :) 